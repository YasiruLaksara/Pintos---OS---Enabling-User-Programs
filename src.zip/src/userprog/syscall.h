#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

void syscall_init (void);



void sys_exit (int);// Terminate the current user program using sys_exit.

#endif /* userprog/syscall.h */