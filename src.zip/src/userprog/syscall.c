#include "threads/synch.h"
#include "threads/vaddr.h"
#include "lib/kernel/list.h"
#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "devices/shutdown.h"
#include "devices/input.h"
#include "filesys/filesys.h"
#include "userprog/process.h"
#include "threads/palloc.h"
#include "filesys/file.h"


// #define_ DEBUG

#ifdef DEBUG
#define _DEBUG_PRINTF(...) printf(__VA_ARGS__)
#else

#define _DEBUG_PRINTF(...)

#endif

static void syscall_handler (struct intr_frame *);

static bool put_user (uint8_t *udst, uint8_t byte);
static int user_memread (void *src, void *des, size_t bytes);
static void check_user (const uint8_t *uaddr);
static int32_t get_user (const uint8_t *uaddr);


/* File System Lock .to ensure that file system operations are atomic and mutually exclusive, preventing race conditions and data corruption. It helps maintain the integrity and consistency of the file system in a multi-threaded or multi-process environment.*/
struct lock filesys_lock;

/* Find File Descriptor. This  allows the operating system or application to manage and manipulate file descriptors for various I/O operations. */
static struct file_desc* find_file_desc(struct thread *, int f_d);

/* Execute Command */
pid_t sys_exec (const char *cmdline);

/* Halt System */
void s_halt (void);

/* Exit System */
void sys_exit (int);

/* Wait for Process */
int s_wait (pid_t pid);

/* Create File */
bool s_create(const char* file_name, unsigned init_size);

/* Remove File */
bool s_remove(const char* file_name);

/* Open File */
int s_open(const char* file);

/* Get File Size */
int s_filesize(int f_d);

/* Set File Position */
void s_seek(int f_d, unsigned position);

/* Get File Position */
unsigned s_tell(int f_d);

/* Close File */
void s_close(int f_d);

/* Read from File */
int s_read(int f_d, void *buffer, unsigned size);

/* Write to File */
int s_write(int f_d, const void *buffer, unsigned size);


void
syscall_init (void)
{
  lock_init (&filesys_lock);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}



static void
syscall_handler (struct intr_frame *f)
{
  int syscall_num;

  // Ensure that the size of syscall_num is as expected (assumes x86).
  ASSERT(sizeof(syscall_num) == 4);

  // Read the system call number from the interrupt frame.
  user_memread(f->esp, &syscall_num, sizeof(syscall_num));


  // Debugging message indicating the system call number.
  _DEBUG_PRINTF("[DEBUG] system call, number = %d!\n", syscall_num);

  switch (syscall_num) {
  case SYS_HALT:
  {
    /* Handle system call with number 0 */
    s_halt();

    NOT_REACHED(); // This code should not be reached; used as a safeguard.

    break;
  }
  case SYS_EXIT:
  {
    /* Handle system call with number 1 */
    int exitcode;
    // Read the exit code from the stack.
    user_memread(f->esp + 4, &exitcode, sizeof(exitcode));

    // Perform the exit operation with the given exit code.
    sys_exit(exitcode);

    NOT_REACHED(); // This code should not be reached.
    break;
  }
  case SYS_EXEC:
    { 
      /* Handle system call with number 2 */
      void* command_line;
      // Read the command line argument from the stack.
      user_memread(f->esp + 4, &command_line, sizeof(command_line));

      // Call sys_exec with the provided command line.
      int ret_code = sys_exec((const char*) command_line);

      // Set the return value in the interrupt frame.
      f->eax = (uint32_t) ret_code;
      break;
    }

  case SYS_WAIT:
    { 
      /* Handle system call with number 3 */
      pid_t pid;

      // Read the process ID (PID) from the stack.
      user_memread(f->esp + 4, &pid, sizeof(pid_t));

      // Call s_wait to wait for the specified process to exit.
      int ret = s_wait(pid);

      // Set the return value in the interrupt frame.
      f->eax = (uint32_t) ret;
      break;
    }

  case SYS_CREATE:
    { 
      /* Handle system call with number 4 */
      const char* file_name;

      unsigned init_size; //Innitial size

      bool ret_code;

      // Read the file name and initial size from the stack.
      user_memread(f->esp + 4, &file_name, sizeof(file_name));
      user_memread(f->esp + 8, &init_size, sizeof(init_size));

      // Call s_create to create a file with the given name and size.
      ret_code = s_create(file_name, init_size);
      // Set the return value in the interrupt frame.
      f->eax = ret_code;
      break;
    }

  case SYS_REMOVE:
    { 
      /* Handle system call with number 5 */
      const char* file_name;

      bool ret_code; //return code

      // Read the file name from the stack.
      user_memread(f->esp + 4, &file_name, sizeof(file_name));

      // Call s_remove to remove the specified file.
      ret_code = s_remove(file_name);
      // Set the return value in the interrupt frame.
      f->eax = ret_code;
      break;
    }

  case SYS_OPEN: 
    { 
      /* Handle system call with number 6 */
      const char* file_name;
      int ret_code;  //return code

      // Memory read from user space.
      user_memread(f->esp + 4, &file_name, sizeof(file_name));

      // Call s_open to open the specified file.
      ret_code = s_open(file_name);

      // Set the return value in the interrupt frame.
      f->eax = ret_code;
      break;
    }

  case SYS_FILESIZE: 
    { 
      /* Handle system call with number 7 */
      int f_d, ret_code;
      // Memory read from user space.
      user_memread(f->esp + 4, &f_d, sizeof(f_d));

      // Call s_filesize to get the size of the specified file.
      ret_code = s_filesize(f_d);

      // Set the return value in the interrupt frame.
      f->eax = ret_code;
      break;
    }

  case SYS_READ:
    { 
      /* Handle system call with number 8 */
      int f_d, ret_code;

      void *buffer;

      unsigned size;

      // Read the file descriptor, buffer, and size from the stack.
      user_memread(f->esp + 4, &f_d, sizeof(f_d));

      user_memread(f->esp + 8, &buffer, sizeof(buffer));

      user_memread(f->esp + 12, &size, sizeof(size));

      // Call s_read to read data from the specified file or standard input.
      ret_code = s_read(f_d, buffer, size);

      // Set the return value in the interrupt frame.
      f->eax = (uint32_t) ret_code;
      break;
    }

  case SYS_WRITE: 
    { 
      /* Handle system call with number 9 */
      int f_d, ret_code;

      const void *buffer;

      unsigned size;

      // Read the file descriptor, buffer, and size from the stack.
      user_memread(f->esp + 4, &f_d, sizeof(f_d));

      user_memread(f->esp + 8, &buffer, sizeof(buffer));

      user_memread(f->esp + 12, &size, sizeof(size));

      // Call s_write to write data to the specified file or standard output.
      ret_code = s_write(f_d, buffer, size);

      // Set the return value in the interrupt frame.
      f->eax = (uint32_t) ret_code;
      break;
    }

  case SYS_SEEK: 
    { 
      /* Handle system call with number 10 */
      int f_d;
      unsigned position;

      // Read the file descriptor and position from the stack.
      user_memread(f->esp + 4, &f_d, sizeof(f_d));

      user_memread(f->esp + 8, &position, sizeof(position));

      // Call s_seek to change the position in the specified file.
      s_seek(f_d, position);
      break;
    }

  case SYS_TELL: 
    { 
      // Handle system call with number 11
      int f_d ;

      unsigned ret_code;

      // Read the file descriptor from the stack.
      user_memread(f->esp + 4, &f_d, sizeof(f_d));

      // Call s_tell to retrieve the current position in the specified file.
      ret_code = s_tell(f_d);

      // Set the return value in the interrupt frame.
      f->eax = (uint32_t) ret_code;

      break;
    }

  case SYS_CLOSE:
    { 
      // Handle system call with number  _12
      int f_d;

      user_memread(f->esp + 4, &f_d, sizeof(f_d));

      // Call s_close to close the specified file.
      s_close(f_d);
      break;
    }

  // Handling unhandled system call _13
  default:

    printf("[ERROR] system call %d is unimplemented!\n", syscall_num);
    sys_exit(-1);

    break;
  }
}


//System Call Implementations



// System call implementation for halting the system.
void s_halt(void) {
  shutdown_power_off();
}

// System call implementation for executing a new process.
pid_t sys_exec(const char *cmd_line) {

  /* Print debugging information */
  _DEBUG_PRINTF("[DEBUG] Executing: %s\n", cmd_line);

  /* Check if cmd_line is a valid address in user memory */
  check_user((const uint8_t*) cmd_line);

  /* Acquire lock before accessing the file system */
  lock_acquire(&filesys_lock);


  /* Execute the process */
  pid_t pid = process_execute(cmd_line);

  /* Release lock after accessing the file system */
  lock_release(&filesys_lock);


  /* Return the process ID */
  return pid;
}


// System call implementation for exiting the current process.
void sys_exit(int status) {

  /* Print process name and exit status */
  printf("%s: exit(%d)\n", thread_current()->name, status);


  /* Get the process control block (PCB) */
  struct process_control_block *pcb = thread_current()->pcb;


  /* If a PCB exists, set exit status */
  if (pcb != NULL) {
    pcb->exited = true;
    pcb->exitcode = status;
  } 
  else {
    /* If PCB does not exist, it means allocation of pages failed in process_execute() */
  }


  /* Exit the process */
  thread_exit();

}


// In case of an invalid memory access, fail and exit.
static void fail_invalid_access(void) {
  if (lock_held_by_current_thread(&filesys_lock))
    lock_release(&filesys_lock);

  sys_exit(-1);
  
  NOT_REACHED();
}

/* sys_wait function
   Waits for the process with the specified PID to exit. */
int s_wait(pid_t pid) {
  // Debug message
  _DEBUG_PRINTF("[DEBUG] Wait: %d\n", pid);

  // Wait for the process with PID to exit
  return process_wait(pid);
}

/* sys_create function
   Creates a file with the specified name and initial size. */
bool s_create(const char* file_name, unsigned initial_size) {
  bool return_code;

  // Validate user memory
  check_user((const uint8_t*) file_name);

  // Acquire the file system lock
  lock_acquire(&filesys_lock);

  // Create the file
  return_code = filesys_create(file_name, initial_size);

  // Release the file system lock
  lock_release(&filesys_lock);

  return return_code;
}
/* sys_remove function
   Removes a file with the specified name. */
bool s_remove(const char* filename) {
  bool return_code;

  // Validate user memory
  check_user((const uint8_t*) filename);

  // Acquire the file system lock
  lock_acquire(&filesys_lock);

  // Remove the file
  return_code = filesys_remove(filename);

  // Release the file system lock
  lock_release(&filesys_lock);

  return return_code;
}

// System call implementation for opening a file.
int s_open(const char* file) {
  // Memory validation
  check_user((const uint8_t*) file);

  struct file* file_opened;  // Declare a pointer to a struct file called file_opened
  struct file_desc* f_d = palloc_get_page(0);  // Declare a pointer to a struct file_desc called f_d and allocate memory for it using palloc_get_page()
  if (!f_d) {
    return -1;
  }

  lock_acquire(&filesys_lock);
  file_opened = filesys_open(file);
  if (!file_opened) {
    palloc_free_page(f_d);
    lock_release(&filesys_lock);
    return -1;
  }

  f_d->file = file_opened; // File saved in the descriptor

  struct list* f_d_list = &thread_current()->file_descriptors;
  if (list_empty(f_d_list)) {
    // 0, 1, 2 are reserved for stdin, stdout, stderr
    f_d->id = 3;
  } else {
    f_d->id = (list_entry(list_back(f_d_list), struct file_desc, elem)->id) + 1;
  }
  list_push_back(f_d_list, &(f_d->elem));

  lock_release(&filesys_lock);
  return f_d->id;
}

// System call implementation for getting the size of a file.
int s_filesize(int f_d) {
  struct file_desc* file_d;

  lock_acquire(&filesys_lock);
  file_d = find_file_desc(thread_current(), f_d);

  if (file_d == NULL) {
    lock_release(&filesys_lock);
    return -1;
  }

  int ret = file_length(file_d->file);
  lock_release(&filesys_lock);
  return ret;
}

// System call implementation for getting the current position in a file.
unsigned s_tell(int f_d) {
  lock_acquire(&filesys_lock);
  struct file_desc* file_d = find_file_desc(thread_current(), f_d);

  unsigned ret;
  if (file_d && file_d->file) {
    ret = file_tell(file_d->file);
  } else {
    ret = -1; // TODO: Need sys_exit?
  }

  lock_release(&filesys_lock);
  return ret;
}

// System call implementation for changing the position in a file.
void s_seek(int f_d, unsigned position) {
  lock_acquire(&filesys_lock);
  struct file_desc* file_d = find_file_desc(thread_current(), f_d);

  if (file_d && file_d->file) {
    file_seek(file_d->file, position);
  } else {
    return; // TODO: Need sys_exit?
  }

  lock_release(&filesys_lock);
}

// System call implementation for closing a file.
void s_close(int f_d) {
  lock_acquire(&filesys_lock);
  struct file_desc* file_d = find_file_desc(thread_current(), f_d);

  if (file_d && file_d->file) {
    file_close(file_d->file);
    list_remove(&(file_d->elem));
    palloc_free_page(file_d);
  }
  lock_release(&filesys_lock);
}

// System call implementation for writing data to a file or standard output.
int s_write(int f_d, const void *buffer, unsigned size) {
  // Memory validation: [buffer, buffer + size) should be all valid
  check_user((const uint8_t*) buffer);
  check_user((const uint8_t*) buffer + size - 1);

  lock_acquire( &filesys_lock);
  int ret;

  if (f_d == 1) { // Write to stdout
    putbuf(buffer,  size);
    ret = size;
  } else {
    // Write into a file
    struct file_desc* file_d = find_file_desc(thread_current(), f_d);

    if (file_d && file_d->file) {
      ret = file_write (file_d->file, buffer, size);
    } else {
      ret = -1; // No such file or can't open
    }
  }

  lock_release(&filesys_lock);
  return ret;
}

// System call implementation for reading data from a file or standard input.
int s_read(int f_d, void *buffer, unsigned size) {
  // Check if the memory range [buffer, buffer + size) is valid
  check_user((const uint8_t*) buffer);
  check_user((const uint8_t*) buffer + size - 1);

  // Acquire a lock to access the file system
  lock_acquire(&filesys_lock);

  int ret;

  // If reading from standard input (f_d = 0)
  if (f_d == 0) {
    // Loop to fill the buffer with input from the user
    for (unsigned i = 0; i < size; ++i) {

      if (!put_user(buffer + i, input_getc())) {

        // Release the lock and exit if a segfault occurs
        lock_release(&filesys_lock);
        sys_exit(-1);
      }
    }
    ret = size;
  } else {
    // Find the file descriptor for the given file
    struct file_desc* file_d = find_file_desc(thread_current(), f_d);

    // If the file exists and can be opened
    if (file_d && file_d->file) {
      // Read from the file
      ret = file_read(file_d->file, buffer, size);
    } else {
      // Return -1 if the file does not exist or cannot be opened
      ret = -1;
    }
  }

  // Release the lock after reading from the file
  lock_release(&filesys_lock);

  return ret;
}

// Helper Functions for Memory Access

// Check if 'uaddr' is within a valid user address range or handle segfaults.
static void check_user(const uint8_t *uaddr) {


  if (get_user(uaddr) == -1)
    fail_invalid_access();
}

// Reads a byte from user memory at 'uaddr' and returns the byte value on success. Returns -1 on error (e.g., segfault or invalid 'uaddr').
static int32_t get_user(const uint8_t *uaddr) {

  if (!((void*) uaddr < PHYS_BASE)) {
    return -1;
  }
  int result;
  asm ("movl $1f, %0; movzbl %1, %0; 1:"
       : "=&a" (result)
       : "m" (*uaddr));
  return result;
}


// Writes a single byte to the user address 'udst' and returns true on successful write, false on segfault.

static bool put_user(uint8_t *udst , uint8_t byte ) {

  if (!((void*)udst < PHYS_BASE)) {

    return false;
  }
  int error_code;

  asm ("movl $1f, %0; movb %b2, %1; 1:"
       : "=&a" (error_code ), "=m" (*udst)
       : "q" (byte));
  return error_code != -1;
}

// Copies bytes from user memory at 'src' to 'dst' and returns the number of bytes copied.
// Exits with a return code of -1 on invalid access.
static int user_memread(void *src, void *dst, size_t bytes) {

  int32_t value;

  for (size_t i = 0; i < bytes ; i++) {

    value = get_user(src + i);

    if (value == -1) {

      fail_invalid_access();

    }

    *(char *)(dst + i) = value & 0xff;

  }
  return (int)bytes;
}

// Finds the file descriptor  _with ID 'f_d' in the thread 't' and returns it .
static struct file_desc *find_file_desc(struct thread *t, int f_d) {
  ASSERT(t != NULL); 
  if (f_d < 3) { 

    return NULL;
  }

  struct list_elem *e;

  if (!list_empty(&t->file_descriptors)) {

    for(e = list_begin(&t->file_descriptors);

        e != list_end(&t->file_descriptors); e = list_next(e))
    {
      struct file_desc *desc = list_entry(e, struct file_desc, elem);

      if(desc->id == f_d) {
        return desc;
      }
    }
  }

  return NULL;  // No matching file descriptor found
}