#ifndef USERPROG_PROCESS_H
#define USERPROG_PROCESS_H

#include "threads/thread.h"

#include "threads/synch.h"


typedef int pid_t;           /* Define 'pid_t' as an integer type for process IDs. */

#define PID_ERROR         ((pid_t) -1)        /* Define 'PID_ERROR' as -1 to indicate an error. */


#define PID_INITIALIZING   ((pid_t) -2 )        /* Define 'PID_INITIALIZING' as -2 for initializing processes. */


pid_t process_execute (const char *cmdline);
int process_wait (tid_t);
void process_exit (void);
void process_activate (void);

/* Process Control Block (PCB) */
struct process_control_block {
    pid_t pid;                /* Process ID of the process. */
    const char* cmdline;      /* Command line for the process being executed. */
    struct list_elem elem;    /* List element for child_list in the thread structure. */
    bool waiting;             /* Indicates if the parent process is waiting on this process. */
    bool exited;              /* Indicates if the process has completed (exited). */
    bool orphan;              /* Indicates if the parent process has terminated before this process. */
    int32_t exitcode;         /* Exit code passed from exit() when exited is true. */

    // For_ Synchronization
    struct semaphore sema_initialization;   /* Semaphore used between process_start() and process_execute(). */
    struct semaphore sema_wait;             /* Semaphore used for wait(): parent blocks until child exits. */
};

// File _Descriptor 
struct file_desc {
    int id;                /* File descriptor ID. */
    struct list_elem elem; /* List element for file descriptor list. */
    struct file* file;     /* Pointer to the file associated with the descriptor. */
};

#endif /* userprog/process.h */
